package com.ids.refuerzoFront;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefuerzoFrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefuerzoFrontApplication.class, args);
	}

}
